/** Automatically generated file. DO NOT MODIFY */
package com.google.android.gms.samples.plus;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}